#!/bin/bash

if [ -f "/opt/victronenergy/swupdate-scripts/check-updates.sh" ]; then
    bash /opt/victronenergy/swupdate-scripts/check-updates.sh -update -force
else
    bash ./check-updates.sh -update -force
fi